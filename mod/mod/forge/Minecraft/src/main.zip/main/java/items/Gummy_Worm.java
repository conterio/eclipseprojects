package items;

import blocks.Candy_Brick;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraftforge.fml.common.registry.GameRegistry;

//class Gummy_Worm
public class Gummy_Worm extends ItemFood {

	
	//constructor
	public Gummy_Worm(int amount, float saturation, boolean isWolfFood) {
		super(amount, saturation, isWolfFood);
		GameRegistry.registerItem(this,"gummyworm");
		this.setUnlocalizedName("gummyworm");
		this.setCreativeTab(CreativeTabs.tabFood);
		this.setPotionEffect(Potion.moveSpeed.id,30,5,1.0F);
		this.setAlwaysEdible();
		
		GameRegistry.addShapedRecipe(new ItemStack(new Candy_Brick(Material.rock)), "###","###","###", '#', GameRegistry.findItem("examplemod", "gummyworm"));
	}

}
