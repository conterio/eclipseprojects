package blocks;

import items.Gummy_Worm;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class Candy_Brick extends Block {

	public Candy_Brick(Material materialIn) {
		super(materialIn);
		GameRegistry.registerBlock(this, "candybrick");
		
		
		this.setUnlocalizedName("candybrick");
		this.setCreativeTab(CreativeTabs.tabBlock);
		this.setHardness(5.0F);
		this.setResistance(10.0F);
		this.setStepSound(Block.soundTypeGravel);

	}
	
	

}
