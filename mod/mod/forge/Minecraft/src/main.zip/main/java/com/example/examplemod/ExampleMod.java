package com.example.examplemod;

import items.*;
import blocks.*;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = ExampleMod.MODID, version = ExampleMod.VERSION)
public class ExampleMod
{
    public static final String MODID = "examplemod";
    public static final String VERSION = "1.0";
    
   
    
    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
    	Item gw =new Gummy_Worm(8,.06F,false);
		gw.setUnlocalizedName("gummyworm");
		gw.setCreativeTab(CreativeTabs.tabFood);
		//gw.setPotionEffect(Potion.moveSpeed.id,30,5,1.0F);
		//gw.setAlwaysEdible();
    	GameRegistry.registerItem(gw,"gummyworm");
    	//GameRegistry.addShapedRecipe(new ItemStack(Items.apple,9), "#",'#',GameRegistry.findBlock("examplemod", "candybrick"));
    	GameRegistry.addShapedRecipe(new ItemStack(GameRegistry.findItem("examplemod", "gummyworm"),9), "#",'#',Blocks.brick_block);
    	//GameRegistry.addShapedRecipe(new ItemStack(Items.apple,9), "#",'#',Blocks.brick_block);
    
    }
    
    @EventHandler
    public void init(FMLInitializationEvent event)
    {
    	
    	
    	if(event.getSide() == Side.CLIENT)
    	{
    		
    	    	RenderItem renderItem = Minecraft.getMinecraft().getRenderItem();
    	    	
    	    	
    	    	//render items****************************************************************************************************
    	    	    	    	
    	    	renderItem.getItemModelMesher().register(new Gummy_Worm(8,.06F,false), 0, new ModelResourceLocation("examplemod:gummyworm", "inventory"));
    	    	renderItem.getItemModelMesher().register(new Chocolate(3,.06F,false), 0, new ModelResourceLocation("examplemod:chocolate", "inventory"));
    	    	renderItem.getItemModelMesher().register(new Chocolate_Milk(), 0, new ModelResourceLocation("examplemod:chocolatemilk", "inventory"));
    	    	renderItem.getItemModelMesher().register(new Cocoa_Powder(), 0, new ModelResourceLocation("examplemod:cocoapowder", "inventory"));
    	    	renderItem.getItemModelMesher().register(new Cotton_Candy(0,false), 0, new ModelResourceLocation("examplemod:cottoncandy", "inventory"));
    	    	renderItem.getItemModelMesher().register(new Gum(0,false), 0, new ModelResourceLocation("examplemod:gum", "inventory"));
    	    	renderItem.getItemModelMesher().register(new Lollipop(2,false), 0, new ModelResourceLocation("examplemod:lollipop", "inventory"));
    	    	renderItem.getItemModelMesher().register(new Sour_Gummy_Worm(1,false), 0, new ModelResourceLocation("examplemod:sourgummyworm", "inventory"));
    	    	
    	    	
    	    	//render blocks****************************************************************************************************
    	    	
    	    	renderItem.getItemModelMesher().register(Item.getItemFromBlock(new Gummy_Dirt()), 0, new ModelResourceLocation("examplemod:gummydirt", "inventory"));
    	    	renderItem.getItemModelMesher().register(Item.getItemFromBlock(new Candy_Sand()), 0, new ModelResourceLocation("examplemod:candysand", "inventory"));
    	    	renderItem.getItemModelMesher().register(Item.getItemFromBlock(new Candy_Brick(Material.rock)), 0, new ModelResourceLocation("examplemod:candybrick", "inventory"));
    	        
    	    	

    	}
        	
    }
}
