package blocks;


import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.fml.common.registry.GameRegistry;

//class Candy_Sand
public class Candy_Sand extends BlockFalling {

	//constructor
	public Candy_Sand() {
		GameRegistry.registerBlock(this, "candysand");
		this.setUnlocalizedName("candysand");
		this.setCreativeTab(CreativeTabs.tabBlock);
		this.setHardness(1.0F);
		this.setResistance(1.0F);
		this.setStepSound(Block.soundTypeSand);
	}

}
